
		<footer>
			<div class='wrapper'>
				<div class='row'>
					<div class='col-xs-12 col-sm-6'>
						<p>Prüfung PHP 1</p>

						<address>
							Ort: WIFI Salzburg<br />
							Trainer: Christian Rainer<br />
							Datum: <?php echo date("d.m.Y"); ?><br />
							&copy; <?php echo date("Y"); ?>
						</address>
					</div>
				</div>
			</div>
		</footer>

	</body>
</html>
