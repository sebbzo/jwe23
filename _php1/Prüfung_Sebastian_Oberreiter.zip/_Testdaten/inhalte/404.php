<div>
  <div class='wrapper'>
    <h1> Error 404 - Das war wohl nix :( </h1>
    <p>
      Diese Seite gibt es bei uns leider nicht (mehr).<br />
      Versuche es doch mal mit der
      <a href="index.php">Startseite</a>.
    </p>
  </div>
</div>
