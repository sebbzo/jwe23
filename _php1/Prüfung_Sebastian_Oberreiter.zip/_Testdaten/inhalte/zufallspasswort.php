		<div id='journal'>
			<div class='wrapper'>
					<div class='row'>
						<div class='col-xs-12'>
								<h1>Zufallspasswort</h1>
						</div>
					</div>

					<div class='row'>
						<div class='col-xs-12'>
							<h2>10 zufällig genierte Passwörter</h2><br>
							<?php include "pwd.php"; ?>
						</div>
					</div>

			</div>
		</div>
