        <footer>
            <hr>
            &copy; Job-DB, Sebastian Oberreiter
        </footer>
    </body>
</html>