
<footer>
    <p>Copyright 2024 Sebastian Oberreiter</p>
</footer>

</body>
</html>