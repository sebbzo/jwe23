<?php

namespace WIFI\Jobportal\Fdb\Model\Row;

class Benutzer extends RowAbstract {
    protected string $tabelle = "benutzer";
}