<?php

namespace WIFI\Jobportal\Fdb\Model\Row;

class Kategorie extends RowAbstract {
    protected string $tabelle = "kategorien";
}