const url = "http://localhost/jwe23/_jobportal/api/categories/list";
let jobList = [];
let getJobsFromAPI = function () {
    $.getJSON(url, function (data) {
        data.result.forEach((element) => {
            jobList.push(element.kategorie);
        });
    }).fail(function () {
        console.log("Fehler beim Laden der Daten");
    });
};

getJobsFromAPI();
$("#load").on("click", function () {
    console.log(jobList);
});

// Wenn job-item angeklickt wird, dann soll der Text in das Feld eingefügt werden
$(document).ready(function () {
    // Delegierter Event-Handler (auch für dynamisch generierte list-item Klassen)
    $("#job-list").on("click", ".list-item", function () {
        var text = $(this).find("p").text();
        $("#search-product").val(text);
    });
});

myList = jobList;
console.log(myList);
mysecList = ["hi", "hi2"];
console.log(mysecList);

let jobArray = Object.values(myList);
console.log(jobArray);

// same as myList.forEach {...}
// Reine Information
$(myList).each(function (i, product) {
    // i ist die Zahl (key), product ist der Name(value)
    console.log(product);
});

/*const addNewProduct = function () {
                                        let value = $("#new-product").val();

                                        let filteredList = myList.filter(function (article) {
                                            return article.toLowerCase().includes(value.toLowerCase());
                                        });

                                        if (!filteredList.length) {
                                            myList.push(value);
                                            Cookies.set("product_list", myList, { expires: 365 });

                                            //Alternative Speichermöglichkeit für Daten in der Local Storage des Browsers
                                            prependNewProduct(
                                                myList.length - 1,
                                                myList[myList.length - 1]
                                            );
                                        } else {
                                            $("#new-product").val("");
                                        }

                                        $("#new-product").val("").focus();
                                    };

                                    $("#add-product").on("click", addNewProduct);

                                    $("#new-product").on("keyup", function (e) {
                                        console.log(e.keyCode);

                                        // Enter wurde gedrückt
                                        if (e.keyCode == 13) {
                                            addNewProduct();
                                        }
                                    });*/

const prependNewProduct = function (index, job) {
    $("#job-list")
        .prepend(`<div class="list-item" data-product-id="${index}"><p>${job}</p>
                                        </div>`);
};

// Hier werden die schon bestehenden Zutaten ausgespielt
const createProductList = function () {
    $(myList).each(prependNewProduct);
};
createProductList();

/*const setCheckedListItems = function () {
                            const cookie = Cookies.get("checked_items");
                            if (typeof cookie != "undefined" && cookie != "") {
                                let checkedItems = cookie.split(",");
                                $(checkedItems).each(function (index, value) {
                                    $("#product-" + value).prop("checked", true);
                                });
                            }
                        };

                        setCheckedListItems();*/

// FILTER FUNKTION

const showFilteredList = function (list) {
    $("#job-list").empty();

    $(list).each(prependNewProduct);
};

// Die Filterfunktion
const filterList = function () {
    let value = $(this).val().toLowerCase();

    let filteredList = myList.filter(function (article) {
        return article.toLowerCase().includes(value);
    });

    showFilteredList(filteredList);
};

$("#search-product").on("keyup", filterList);

// lesen der aktuell gechecked inputs
// bauen des Arrays mit der Liste aller product-IDs der Elemente die gecheckt sind
// Speichern in Cookies

let checkedInputs;

$("#job-list input").change(function () {
    let listOfCheckedInputs = [];

    let checkedInputs = $("input:checked");
    checkedInputs.each(function () {
        let productId = $(this).closest("[data-product-id]").data("product-id");
        console.log(productId);
        listOfCheckedInputs.push(productId);
        console.log(listOfCheckedInputs);
    });

    /*Cookies.set("checked_items", listOfCheckedInputs.join(","), {
                                expires: 365,
                            });*/
});
