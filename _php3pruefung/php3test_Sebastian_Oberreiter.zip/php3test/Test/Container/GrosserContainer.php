<?php

namespace WIFI\Php3\Test\Container;

class GrosserContainer extends ContainerAbstract {

    protected float $leergewicht = 4.0;
    protected float $nutzlast = 26.48;
    protected string $name_container = "Grosser Container";

}