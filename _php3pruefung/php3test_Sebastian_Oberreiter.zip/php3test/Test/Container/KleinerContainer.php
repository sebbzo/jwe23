<?php

namespace WIFI\Php3\Test\Container;

class KleinerContainer extends ContainerAbstract {

    protected float $leergewicht = 2.33;
    protected float $nutzlast = 21.67;
    protected string $name_container = "Kleiner Container";

}