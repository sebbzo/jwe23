<?php
include "funktionen.php";
include "kopf.php";
?>
    <h1>Flug-DB</h1>

    <p>
      Bitte wählen Sie einen Menüpunkt aus der Leiste oben aus.
    </p>

<?php
include "fuss.php";
?>
