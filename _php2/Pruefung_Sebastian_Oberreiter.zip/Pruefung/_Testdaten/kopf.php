<!DOCTYPE html>
<html>
  <head>
    <title>Administration</title>
    <meta charset='utf-8' />
    <link href='bootstrap.min.css' type='text/css' rel='stylesheet' />
  </head>
  <body>
    <nav>
      <ul>
        <li><a href='index.php'>Start</a></li>
        <li><a href='flug_liste.php'>Flüge</a></li>
        <li><a href='passagiere_liste.php'>Passagiere</a></li>
      </ul>
    </nav>
